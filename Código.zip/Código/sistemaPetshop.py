# -------CLASSES-------
# Classe Veterinário
class Veterinario:
    def __init__(self, nome, idade, sexo, cpf, especialicacao):
        self.nome = nome
        self.idade = idade
        self.sexo = sexo
        self.cpf = cpf
        self.especialicacao = especialicacao

    def exibir_info(self):
        print(f"Nome: {self.nome}")
        print(f"Idade: {self.idade}")
        print(f"Sexo: {self.sexo}")
        print(f"CPF: {self.cpf}")
        print(f"Especialização: {self.especialicacao}")
        print("----------------------")

# Classe Animal
class Animal:
    def __init__(self, nome, especie, idade: int, peso, dono):
        self.nome = nome
        self.especie = especie
        self.idade = idade
        self.peso = peso
        self.dono = dono

    def exibir_info(self):
        print(f"Nome: {self.nome}")
        print(f"Espécie: {self.especie}")
        print(f"Idade: {self.idade}")
        print(f"Peso: {self.peso}")
        print(f"Dono: {self.dono}")
        print("----------------------")

# Classe Consulta
class Consulta:
    def __init__(self, animal, data, hora):
        self.animal = animal
        self.data = data
        self.hora = hora

    def exibir_info(self):
        print(f"Data: {self.data}")
        print(f"Hora: {self.hora}")
        self.animal.exibir_info()
        print("----------------------")

# Classe Prontuário
class Prontuario:
    def __init__(self, identificador, veterinario, animal, data, exame, prescricao):
        self.identificador = identificador
        self.veterinario = veterinario
        self.animal = animal
        self.data = data
        self.exame = exame
        self.prescricao = prescricao

    def exibir_info(self):
        print(f"ID: {self.identificador}")
        print(f"Data: {self.data}")
        print(f"Exames: {self.exame}")
        print(f"Prescrição: {self.prescricao}")
        self.veterinario.exibir_info()
        self.animal.exibir_info()
        print("----------------------")

# -------LISTAS-------
# Lista de veterinarios
veterinarios = []
# Lista de animais
animais = []
# Lista de consultas
consultas = []
# Lista de prontuarios
prontuarios = []

# -------FUNÇÕES-------
# -------FUNÇÕES VETERINÁRIO-------
# Função para cadastrar um veterinario
def cadastrar_veterinario():
    nome = input("Digite o nome do(a) profissional: ")
    idade = input("Digite a idade do(a) profissional: ")
    sexo = input("Digite o sexo do(a) profissional: ")
    cpf = input("Digite o CPF do(a) profissional: ")
    especialicacao = input("Digite o especialização do(a) profissional: ")
    veterinario = Veterinario(nome, idade, sexo, cpf, especialicacao)
    veterinarios.append(veterinario)
    print("Profissional cadastrado com sucesso!")
    veterinario.exibir_info()

# Função para exibir a lista de veterinários cadastrados
def exibir_veterinarios():
    if not veterinarios:
        print("Não há profissionais cadastrados.")
    else:
        for veterinario in veterinarios:
            veterinario.exibir_info()

# Função para editar as informações de um veterinário cadastrado
def editar_veterinario():
    if not veterinarios:
        print("Não há profissionais cadastrados.")
        return
    nome = input("Digite o nome do(a) profissional que deseja editar: ")
    veterinario = None
    for v in veterinarios:
        if v.nome == nome:
            veterinario = v
            break
    if not veterinario:
        print("Profissional não encontrado.")
        return
    print(f"Informações atuais do(a) profissional {veterinario.nome}: ")
    veterinario.exibir_info()
    print("Digite as novas informações do(a) profissional: ")
    nome = input("Nome: ")
    idade = input("Idade: ")
    sexo = input("Sexo: ")
    cpf = input("CPF: ")
    especialicacao = input("Especialização: ")
    veterinario.nome = nome
    veterinario.idade = idade
    veterinario.sexo = sexo
    veterinario.cpf = cpf
    veterinario.especialicacao = especialicacao
    print(f"As informações do(a) profissional {veterinario.nome} foram atualizadas com sucesso!")
    veterinario.exibir_info()

# Função para excluir as informações de um veterinário cadastrado
def excluir_veterinario():
    if not veterinarios:
        print("Não há profissionais cadastrados.")
        return
    nome = input("Digite o nome do(a) profissional que deseja excluir: ")
    veterinario = None
    for v in veterinarios:
        if v.nome == nome:
            veterinario = v
            break
    if not veterinario:
        print("Profissional não encontrado.")
        return
    veterinarios.remove(veterinario)
    print(f"O(a) profissional {veterinario.nome} foi excluído(a) com sucesso!")

# Função para exibir a lista de veterinários pelo sexo escolhido
def buscar_vet_por_sexo():
    if not veterinarios:
        print("Não há profissionais cadastrados.")
        return
    sexo = input("Informe o sexo dos veterinários desejado (M/F): ")
    for veterinario in veterinarios:
        if veterinario.sexo == sexo:
            veterinario.exibir_info()
        else:
            print("Opção inválida.")

# Função para exibir a lista de veterinários por especialização
def buscar_vet_por_especializacao():
    if not veterinarios:
        print("Não há profissionais cadastrados.")
        return
    especialicacao = input("Informe a especialização do veterinário: ")
    for veterinario in veterinarios:
        if veterinario.especialicacao == especialicacao:
            veterinario.exibir_info()
        else:
            print("Opção inválida.")

# -------FUNÇÕES ANIMAL-------
# Função para cadastrar um animal
def cadastrar_animal():
    nome = input("Digite o nome do animal: ")
    especie = input("Digite a espécie do animal: ")
    idade = int(input("Digite a idade do animal: "))
    peso = input("Digite o peso do animal: ")
    dono = input("Digite o nome do dono do animal: ")
    animal = Animal(nome, especie, idade, peso, dono)
    animais.append(animal)
    print("Animal cadastrado com sucesso!")
    animal.exibir_info()

# Função para exibir a lista de animais cadastrados
def exibir_animais():
    if not animais:
        print("Não há animais cadastrados.")
    else:
        for animal in animais:
            animal.exibir_info()

# Função para pesquisar um animal através do seu nome
def consultar_animal_por_nome():
    if not animais:
        print("Não há animais cadastrados.")
        return
    nome = input("Digite o nome do animal que deseja pesquisar: ")
    animal = None
    for a in animais:
        if a.nome == nome:
            animal = a
            break
    if not animal:
        print("Animal não encontrado.")
        return
    print(f"Informações atuais do animal {animal.nome}: ")
    animal.exibir_info()

# Função para mostrar quantos animais possuem mais de 10 anos
def contar_animais_mais_de_10_anos():
    qtd = 0
    for animal in animais:
        if animal.idade > 10:
            qtd += 1
    print("Quantidade de animais com mais de 10 anos:", qtd)

# Função para editar as informações de um animal cadastrado
def editar_animal():
    if not animais:
        print("Não há animais cadastrados.")
        return
    nome = input("Digite o nome do animal que deseja editar: ")
    animal = None
    for a in animais:
        if a.nome == nome:
            animal = a
            break
    if not animal:
        print("Animal não encontrado.")
        return
    print(f"Informações atuais do animal {animal.nome}: ")
    animal.exibir_info()
    print("Digite as novas informações do animal: ")
    nome = input("Nome: ")
    especie = input("Espécie: ")
    idade = input("Idade: ")
    peso = input("Peso: ")
    dono = input("Nome do dono: ")
    animal.nome = nome
    animal.especie = especie
    animal.idade = idade
    animal.peso = peso
    animal.dono = dono
    print(f"As informações do animal {animal.nome} foram atualizadas com sucesso!")
    animal.exibir_info()

# Função para excluir as informações de um animal cadastrado
def excluir_animal():
    if not animais:
        print("Não há animais cadastrados.")
        return
    nome = input("Digite o nome do animal que deseja excluir: ")
    animal = None
    for a in animais:
        if a.nome == nome:
            animal = a
            break
    if not animal:
        print("Animal não encontrado.")
        return
    animais.remove(animal)
    print(f"O animal {nome} foi removido com sucesso!")

# -------FUNÇÕES CONSULTA-------
# Função para agendar uma consulta
def agendar_consulta():
    if not animais:
        print("Não há animais cadastrados.")
        return
    nome = input("Digite o nome do animal para agendar a consulta: ")
    animal = None
    for a in animais:
        if a.nome == nome:
            animal = a
            break
    if not animal:
        print("Animal não encontrado.")
        return
    data = input("Digite a data da consulta (dd/mm/aaaa): ")
    hora = input("Digite a hora da consulta (hh:mm): ")
    consulta = Consulta(animal, data, hora)
    consultas.append(consulta)
    print("Consulta agendada com sucesso!")
    consulta.exibir_info()

# Função para exibir a lista de consultas agendadas
def exibir_consultas():
    if not consultas:
        print("Não há consultas agendadas.")
    else:
        for consulta in consultas:
            consulta.exibir_info()

# Função para editar as informações de uma consulta cadastrada
def editar_consulta():
    if not consultas:
        print("Não há consultas cadastradas.")
        return
    data_hora = input("Digite a data e hora da consulta que deseja editar (no formato dd/mm/aaaa hh:mm): ")
    consulta = None
    for c in consultas:
        if c.data + " " + c.hora == data_hora:
            consulta = c
            break
    if not consulta:
        print("Consulta não encontrada.")
        return
    print(f"Informações atuais da consulta do animal {consulta.animal.nome} na data {consulta.data} às {consulta.hora}: ")
    consulta.exibir_info()
    print("Digite as novas informações da consulta: ")
    data = input("Data (no formato dd/mm/aaaa): ")
    hora = input("Hora (no formato hh:mm): ")
    consulta.data = data
    consulta.hora = hora
    print(f"As informações da consulta do animal {consulta.animal.nome} foram atualizadas com sucesso!")
    consulta.exibir_info()

def excluir_consulta():
    if not consultas:
        print("Não há consultas cadastradas.")
        return
    data = input("Digite a data da consulta que deseja excluir (formato dd/mm/aaaa): ")
    hora = input("Digite a hora da consulta que deseja excluir (formato hh:mm): ")
    consulta = None
    for c in consultas:
        if c.data == data and c.hora == hora:
            consulta = c
            break
    if not consulta:
        print("Consulta não encontrada.")
        return
    consultas.remove(consulta)
    print("Consulta excluída com sucesso!")
    consulta.exibir_info()

# Função para pesquisar uma consulta através de um animal
def consultar_consulta_por_animal():
    if not consultas:
        print("Não há consultas agendadas.")
        return
    nome = input("Digite o nome do animal: ")
    encontrou_consulta = False
    for consulta in consultas:
        if consulta.animal.nome.lower() == nome.lower():
            consulta.exibir_info()
            encontrou_consulta = True
    if not encontrou_consulta:
        print(f"Não há consultas agendadas para o animal {nome}.")

# -------FUNÇÕES PRONTUÁRIO-------
# Função para criar um prontuário
def criar_prontuario():
    if not veterinarios:
        print("Não há profissionais cadastrados.")
        return
    nome = input("Digite o nome do profissional para criar o prontuário: ")
    veterinario = None
    for a in veterinarios:
        if a.nome == nome:
            veterinario = a
            break
    if not veterinario:
        print("Profissional não encontrado.")
        return
    if not animais:
        print("Não há animais cadastrados.")
        return
    nome = input("Digite o nome do animal para agendar a consulta: ")
    animal = None
    for a in animais:
        if a.nome == nome:
            animal = a
            break
    if not animal:
        print("Animal não encontrado.")
        return
    identificador = input("Digite um ID de até 3 dígitos: ")
    data = input("Digite a data do prontuário (dd/mm/aaaa): ")
    exame = input("Digite os exames: ")
    prescricao = input("Digite a prescrição: ")
    prontuario = Prontuario(identificador, veterinario, animal, data, exame, prescricao)
    prontuarios.append(prontuario)
    print("Prontuário criado com sucesso!")
    prontuario.exibir_info()

# Função para exibir a lista de prontuários criados
def exibir_prontuarios():
    if not prontuarios:
        print("Não há prontuários criados.")
    else:
        for prontuario in prontuarios:
            prontuario.exibir_info()

# Função para editar a lista de prontuários criados
def editar_prontuario():
    if not prontuarios:
        print("Não há prontuários cadastrados.")
        return
    identificador = input("Digite o ID do prontuário que deseja editar: ")
    prontuario = None
    for p in prontuarios:
        if p.identificador == identificador:
            prontuario = p
            break
    if not prontuario:
        print("Prontuário não encontrado.")
        return
    print(f"Informações atuais do prontuário {prontuario.identificador}: ")
    prontuario.exibir_info()
    print("Digite as novas informações do prontuário: ")
    data = input("Data: ")
    exame = input("Exames: ")
    prescricao = input("Prescrição: ")
    prontuario.data = data
    prontuario.exame = exame
    prontuario.prescricao = prescricao
    print(f"As informações do prontuário {prontuario.identificador} foram atualizadas com sucesso!")
    prontuario.exibir_info()

# Função para excluir prontuários criados
def excluir_prontuario():
    if not prontuarios:
        print("Não há prontuários cadastrados.")
        return
    identificador = input("Digite o ID do prontuário que deseja excluir: ")
    prontuario = None
    for p in prontuarios:
        if p.identificador == identificador:
            prontuario = p
            break
    if not prontuario:
        print("Prontuário não encontrado.")
        return
    prontuarios.remove(prontuario)
    print(f"O prontuário com ID {prontuario.identificador} foi excluído com sucesso!")
    prontuario.exibir_info()

# Função para exibir prontuário através do ID
def pesquisar_prontuario_por_id():
    if not prontuarios:
        print("Não há prontuários cadastrados.")
        return
    identificador = input("Digite o ID do prontuário que deseja pesquisar: ")
    prontuario = None
    for p in prontuarios:
        if p.identificador == identificador:
            prontuario = p
            break
    if not prontuario:
        print("Prontuário não encontrado.")
        return
    print(f"Informações atuais do prontuário {prontuario.identificador}: ")
    prontuario.exibir_info()

# Função para exibir prontuário através da data
def pesquisar_prontuario_por_data():
    if not prontuarios:
        print("Não há prontuários cadastrados.")
        return
    data = input("Digite a data do prontuário que deseja pesquisar (dd/mm/aaaa): ")
    prontuario = None
    for p in prontuarios:
        if p.data == data:
            prontuario = p
            break
    if not prontuario:
        print("Prontuário não encontrado.")
        return
    print(f"Informações atuais do prontuário da data de {prontuario.data}: ")
    prontuario.exibir_info()

# -------MENUS-------
# -------MENU ANIMAL-------
def menu_animal():
    while True:
        print("\n-------Menu do Animal-------")
        print("1 - Cadastrar animal")
        print("2 - Exibir animais cadastrados")
        print("3 - Pesquisar animal por nome")
        print("4 - Visualizar quantidade de animais com mais de 10 anos")
        print("0 - Voltar para o menu anterior")
        opcao = input("Opção: ")
        if opcao == "1":
            cadastrar_animal()
        elif opcao == "2":
            exibir_animais()
        elif opcao == "3":
            consultar_animal_por_nome()
        elif opcao == "4":
            contar_animais_mais_de_10_anos()
        elif opcao == "0":
            menu_principal()
            break
        else:
            print("Opção inválida.")

# -------MENU VETERINÁRIO-------
def menu_veterinario():
    while True:
        print("\n-------Menu do Veterinário-------")
        print("1 - Cadastrar veterinário")
        print("2 - Exibir veterinários cadastrados")
        print("3 - Exibir veterinários por sexo")
        print("4 - Exibir veterinários por especialização")
        print("0 - Voltar para o menu anterior")
        opcao = input("Opção: ")
        if opcao == "1":
            cadastrar_veterinario()
        elif opcao == "2":
            exibir_veterinarios()
        elif opcao == "3":
            buscar_vet_por_sexo()
        elif opcao == "4":
            buscar_vet_por_especializacao()
        elif opcao == "0":
            menu_principal()
            break
        else:
            print("Opção inválida.")

# -------MENU CONSULTA-------
def menu_consulta():
    while True:
        print("\n-------Menu de Consulta-------")
        print("1 - Agendar consulta")
        print("2 - Exibir consultas agendadas")
        print("3 - Pesquisar consulta por animal")
        print("0 - Voltar para o menu anterior")
        opcao = input("Opção: ")
        if opcao == "1":
            agendar_consulta()
        elif opcao == "2":
            exibir_consultas()
        elif opcao == "3":
            consultar_consulta_por_animal()
        elif opcao == "0":
            menu_principal()
            break
        else:
            print("Opção inválida.")

# -------MENU PRONTUÁRIO-------
def menu_prontuario():
    while True:
        print("\n-------Menu de Prontuário-------")
        print("1 - Criar prontuário")
        print("2 - Exibir prontuários criados")
        print("3 - Pesquisar prontuário por ID")
        print("4 - Pesquisar prontuário por data")
        print("0 - Voltar para o menu anterior")
        opcao = input("Opção: ")
        if opcao == "1":
            criar_prontuario()
        elif opcao == "2":
            exibir_prontuarios()
        elif opcao == "3":
            pesquisar_prontuario_por_id()
        elif opcao == "4":
            pesquisar_prontuario_por_data()
        elif opcao == "0":
            menu_principal()
            break
        else:
            print("Opção inválida.")

# -------MENU ADM ACESSADO-------
def menu_adm_acesso():
    while True:
        print("\n-------Menu do Administrador-------")
        print("\n-------Animais-------")
        print("1 - Exibir animais cadastrados")
        print("2 - Editar animais cadastrados")
        print("3 - Excluir animais cadastrados")
        print("\n-------Veterinários-------")
        print("4 - Exibir veterinários cadastrados")
        print("5 - Editar veterinários cadastrados")
        print("6 - Excluir veterinários cadastrados")
        print("\n-------Consultas-------")
        print("7 - Exibir consultas agendadas")
        print("8 - Editar consultas agendadas")
        print("9 - Excluir consultas agendadas")
        print("\n-------Prontuários-------")
        print("10 - Exibir prontuários criados")
        print("11 - Editar prontuários criados")
        print("12 - Excluir prontuários criados")
        print("\n---------------------")
        print("0 - Voltar para o menu anterior")
        opcao = input("Opção: ")
        if opcao == "1":
            exibir_animais()
        elif opcao == "2":
            editar_animal()
        elif opcao == "3":
            excluir_animal()
        elif opcao == "4":
            exibir_veterinarios()
        elif opcao == "5":
            editar_veterinario()
        elif opcao == "6":
            excluir_veterinario()
        elif opcao == "7":
            exibir_consultas()
        elif opcao == "8":
            editar_consulta()
        elif opcao == "9":
            excluir_consulta()
        elif opcao == "10":
            exibir_prontuarios()
        elif opcao == "11":
            editar_prontuario()
        elif opcao == "12":
            excluir_prontuario()
        elif opcao == "0":
            menu_principal()
            break
        else:
            print("Opção inválida.")

# -------MENU ADM-------
def menu_adm():
    while True:
        print("\n-------Menu do Administrador-------")
        print("1 - Inserir senha de acesso")
        print("0 - Voltar para o menu anterior")
        opcao = input("Opção: ")
        if opcao == "1":
            senha = int(input("\nDigite a senha: "))
            if senha == 123:
                menu_adm_acesso()
                break
            else:
                print("Senha inválida.")
                menu_adm()
                break
        elif opcao == "0":
            menu_principal()
            break
        else:
            print("Opção inválida.")
        
# -------CÓPIA COMO FUNÇÃO - MENU PRINCIPAL-------
def menu_principal():
    while True:
        print("\n-------Bem-vindo ao Petshop Pettopia-------")
        print("Selecione uma opção:")
        print("1 - Acessar menu do animal")
        print("2 - Acessar menu do veterinário")
        print("3 - Acessar menu de consulta")
        print("4 - Acessar menu de prontuário")
        print("5 - Acessar menu do administrador")
        print("0 - Sair")
        opcao = input("Opção: ")
        if opcao == "1":
            menu_animal()
            break
        elif opcao == "2":
            menu_veterinario()
            break
        elif opcao == "3":
            menu_consulta()
            break
        elif opcao == "4":
            menu_prontuario()
            break
        elif opcao == "5":
            menu_adm()
            break
        elif opcao == "0":
            print("\nSaindo...")
            break
        else:
            print("Opção inválida.")

# -------MENU PRINCIPAL-------
while True:
    print("\n-------Bem-vindo ao Petshop Pettopia-------")
    print("Selecione uma opção:")
    print("1 - Acessar menu do animal")
    print("2 - Acessar menu do veterinário")
    print("3 - Acessar menu de consulta")
    print("4 - Acessar menu de prontuário")
    print("5 - Acessar menu do administrador")
    print("6 - Sobre o sistema")
    print("0 - Sair")
    opcao = input("Opção: ")
    if opcao == "1":
        menu_animal()
        break
    elif opcao == "2":
        menu_veterinario()
        break
    elif opcao == "3":
        menu_consulta()
        break
    elif opcao == "4":
        menu_prontuario()
        break
    elif opcao == "5":
        menu_adm()
        break
    elif opcao == "6":
        print('''\nProjeto Interdisciplinar v1.0\n
• Cauan do Carmo Braga - RGM 29491291
• Lucas de Souza Mendes - RGM: 29474248
• Luis Gustavo Pereira Ribeiro - RGM: 29426154''')
    elif opcao == "0":
        print("\nSaindo...")
        break
    else:
        print("Opção inválida.")
